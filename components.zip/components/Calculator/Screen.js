import React, { useRef, useEffect } from 'react';

const Screen = (props) => {
  const inputRef = useRef(null);

  const changeHandler = () => {
    props.onManualEnter(inputRef.current.value);
  };

  const onSubmitHandler = (event) => {
    event.preventDefault();
    if (inputRef.current.value.length > 0) {
      let answer = parseInt(inputRef.current.value);
      props.onCheckProduct(answer);
    }
  };

  useEffect(() => {
    if (props.isCorrect === 'Correct') {
      inputRef.current.setAttribute('style', 'background-color: #79e36d');
      setTimeout(() => {
        inputRef.current.setAttribute('style', 'background-color: #ccd4cb');
      }, 250);
    }
    if (props.isCorrect === 'Wrong') {
      inputRef.current.setAttribute('style', 'background-color: #f75252');
      setTimeout(() => {
        inputRef.current.setAttribute('style', 'background-color: #ccd4cb');
      }, 250);
    }
  });

  return (
    <form className="screen" onSubmit={onSubmitHandler}>
      <div className="product">{props.product}</div>
      <input
        className="inputAnswer"
        type="number"
        onChange={changeHandler}
        ref={inputRef}
        value={props.digits}
      />
    </form>
  );
};

export default Screen;
