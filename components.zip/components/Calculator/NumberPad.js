import React from 'react';
import { Button, View } from 'react-native';


const NumberPad = (props) => {
    const clickHandler = (event) => {
        props.onEnteredDigit(event.target.title);
    };
    return (
        <View className="numberPad">
            <View>
                <Button className="digit" onClick={clickHandler} title="7" />
                <Button className="digit" onClick={clickHandler} title="8" />
                <Button className="digit" onClick={clickHandler} title="9" />
            </View>
            <View>
                <Button className="digit" onClick={clickHandler} title="4" />
                <Button className="digit" onClick={clickHandler} title="5" />
                <Button className="digit" onClick={clickHandler} title="6" />
            </View>
            <View>
                <Button className="digit" onClick={clickHandler} title="1" />
                <Button className="digit" onClick={clickHandler} title="2" />
                <Button className="digit" onClick={clickHandler} title="3" />
            </View>
            <View className="lastRow">
                <Button className="del" onClick={clickHandler} title="del" />
                <Button className="digit" onClick={clickHandler} title="0" />
                <Button
                    className="enter"
                    onClick={props.digits.length > 0 ? clickHandler : undefined}
                    title="enter" />
            </View>
        </View>
    );
};

export default NumberPad;
